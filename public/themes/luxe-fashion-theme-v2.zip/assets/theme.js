/* ============================================================
   ASIAN FOOTWEARS - SHOPIFY THEME JS
   ============================================================ */

(function() {
  'use strict';

  // ============================================================
  // HERO SLIDER
  // ============================================================
  var HeroSlider = {
    slider: null,
    slides: null,
    dots: null,
    currentIndex: 0,
    total: 0,
    interval: null,

    init: function() {
      this.slider = document.getElementById('HeroSlider');
      if (!this.slider) return;
      this.slides = this.slider.querySelectorAll('.hero-slide');
      this.dots = this.slider.querySelectorAll('.dot');
      this.total = this.slides.length;
      if (this.total <= 1) return;

      var prevBtn = document.getElementById('SliderPrev');
      var nextBtn = document.getElementById('SliderNext');
      var slidesWrap = this.slider.querySelector('.hero-slides');
      this.slidesWrap = slidesWrap;

      if (prevBtn) prevBtn.addEventListener('click', this.prev.bind(this));
      if (nextBtn) nextBtn.addEventListener('click', this.next.bind(this));

      this.dots.forEach(function(dot, i) {
        dot.addEventListener('click', function() { HeroSlider.goTo(i); });
      });

      this.startAuto();
      this.slider.addEventListener('mouseenter', this.stopAuto.bind(this));
      this.slider.addEventListener('mouseleave', this.startAuto.bind(this));
    },

    goTo: function(index) {
      this.currentIndex = (index + this.total) % this.total;
      this.slidesWrap.style.transform = 'translateX(-' + (this.currentIndex * 100) + '%)';
      this.dots.forEach(function(d, i) {
        d.classList.toggle('active', i === HeroSlider.currentIndex);
      });
    },

    next: function() { this.goTo(this.currentIndex + 1); },
    prev: function() { this.goTo(this.currentIndex - 1); },

    startAuto: function() {
      this.stopAuto();
      this.interval = setInterval(function() { HeroSlider.next(); }, 5000);
    },
    stopAuto: function() {
      if (this.interval) clearInterval(this.interval);
    }
  };

  // ============================================================
  // MOBILE MENU
  // ============================================================
  var MobileMenu = {
    init: function() {
      var toggle = document.getElementById('MobileMenuToggle');
      var menu = document.getElementById('MobileMenu');
      var overlay = document.getElementById('MobileMenuOverlay');
      var close = document.getElementById('MobileMenuClose');

      if (!toggle || !menu) return;

      function open() {
        menu.classList.add('active');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
      function closeFn() {
        menu.classList.remove('active');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
      }

      toggle.addEventListener('click', open);
      if (close) close.addEventListener('click', closeFn);
      if (overlay) overlay.addEventListener('click', closeFn);

      // Sub-menus
      var subItems = menu.querySelectorAll('.mobile-has-sub > a');
      subItems.forEach(function(link) {
        link.addEventListener('click', function(e) {
          e.preventDefault();
          var parent = this.closest('.mobile-has-sub');
          parent.classList.toggle('open');
        });
      });
    }
  };

  // ============================================================
  // STICKY HEADER
  // ============================================================
  var StickyHeader = {
    init: function() {
      var header = document.getElementById('SiteHeader');
      if (!header) return;
      var lastScroll = 0;
      window.addEventListener('scroll', function() {
        var current = window.scrollY;
        if (current > 200) {
          header.classList.add('header--scrolled');
        } else {
          header.classList.remove('header--scrolled');
        }
        lastScroll = current;
      }, { passive: true });
    }
  };

  // ============================================================
  // PRODUCT GALLERY
  // ============================================================
  var ProductGallery = {
    init: function() {
      var thumbs = document.querySelectorAll('.product-gallery__thumb');
      var slides = document.querySelectorAll('.product-gallery__slide');
      if (!thumbs.length) return;

      thumbs.forEach(function(thumb) {
        thumb.addEventListener('click', function() {
          var idx = parseInt(this.dataset.index);
          thumbs.forEach(function(t) { t.classList.remove('active'); });
          slides.forEach(function(s) { s.classList.remove('active'); });
          this.classList.add('active');
          if (slides[idx]) slides[idx].classList.add('active');
        });
      });
    }
  };

  // ============================================================
  // PRODUCT VARIANT SELECTOR
  // ============================================================
  var ProductVariants = {
    init: function() {
      var form = document.getElementById('ProductForm');
      if (!form) return;

      var radios = form.querySelectorAll('input[type="radio"]');
      radios.forEach(function(radio) {
        radio.addEventListener('change', function() {
          // Update label display
          var option = this.closest('.product-option');
          if (option) {
            var labelEl = option.querySelector('[id^="SelectedOption"]');
            if (labelEl) labelEl.textContent = this.value;
            var siblings = option.querySelectorAll('label');
            siblings.forEach(function(l) { l.classList.remove('active'); });
            this.closest('label') && this.closest('label').classList.add('active');
          }
          ProductVariants.updateVariant(form);
        });
      });
    },

    updateVariant: function(form) {
      var selected = [];
      [0, 1, 2].forEach(function(i) {
        var checked = form.querySelector('input[name="option' + i + '"]:checked');
        if (checked) selected.push(checked.value);
      });

      // Find matching variant from Shopify JS API
      if (window.__product_variants) {
        var match = window.__product_variants.find(function(v) {
          return selected.every(function(s, i) { return v['option' + (i+1)] === s || !s; });
        });
        if (match) {
          var idInput = document.getElementById('ProductVariantId');
          var priceEl = document.getElementById('ProductPrice');
          var compareEl = document.getElementById('ProductComparePrice');
          var addBtn = document.getElementById('AddToCart');
          if (idInput) idInput.value = match.id;
          if (priceEl) priceEl.textContent = ProductVariants.formatMoney(match.price);
          if (compareEl && match.compare_at_price > match.price) {
            compareEl.textContent = ProductVariants.formatMoney(match.compare_at_price);
            compareEl.style.display = '';
          } else if (compareEl) {
            compareEl.style.display = 'none';
          }
          if (addBtn) {
            addBtn.disabled = !match.available;
            addBtn.textContent = match.available ? 'Add to Cart' : 'Sold Out';
          }
        }
      }
    },

    formatMoney: function(cents) {
      return '₹' + (cents / 100).toLocaleString('en-IN');
    }
  };

  // ============================================================
  // QUANTITY SELECTOR
  // ============================================================
  var QuantitySelector = {
    init: function() {
      document.addEventListener('click', function(e) {
        if (e.target.classList.contains('qty-btn--minus')) {
          var input = e.target.nextElementSibling;
          if (input && parseInt(input.value) > 1) {
            input.value = parseInt(input.value) - 1;
            input.dispatchEvent(new Event('change'));
          }
        }
        if (e.target.classList.contains('qty-btn--plus')) {
          var input = e.target.previousElementSibling;
          if (input) {
            var max = parseInt(input.max) || 99;
            if (parseInt(input.value) < max) {
              input.value = parseInt(input.value) + 1;
              input.dispatchEvent(new Event('change'));
            }
          }
        }
      });
    }
  };

  // ============================================================
  // PRODUCT TABS (on product page)
  // ============================================================
  var ProductTabs = {
    init: function() {
      var btns = document.querySelectorAll('.product-tab-btn');
      if (!btns.length) return;
      btns.forEach(function(btn) {
        btn.addEventListener('click', function() {
          var tab = this.dataset.tab;
          btns.forEach(function(b) { b.classList.remove('active'); });
          document.querySelectorAll('.product-tab-content').forEach(function(c) { c.classList.remove('active'); });
          this.classList.add('active');
          var content = document.getElementById('tab-' + tab);
          if (content) content.classList.add('active');
        });
      });
    }
  };

  // ============================================================
  // COLLECTION FILTER GROUPS (accordion)
  // ============================================================
  var FilterAccordion = {
    init: function() {
      var titles = document.querySelectorAll('.filter-group__title');
      titles.forEach(function(title) {
        title.addEventListener('click', function() {
          var content = this.nextElementSibling;
          var isOpen = content.style.display !== 'none';
          content.style.display = isOpen ? 'none' : '';
          var icon = this.querySelector('i');
          if (icon) icon.classList.toggle('fa-chevron-up', !isOpen);
        });
      });
    }
  };

  // ============================================================
  // SORT BY (redirect with sort param)
  // ============================================================
  var SortBy = {
    init: function() {
      var select = document.getElementById('SortBy');
      if (!select) return;
      select.addEventListener('change', function() {
        var url = new URL(window.location.href);
        url.searchParams.set('sort_by', this.value);
        window.location.href = url.toString();
      });
    }
  };

  // ============================================================
  // MOBILE FILTER TOGGLE
  // ============================================================
  var FilterToggle = {
    init: function() {
      var btn = document.getElementById('FilterToggle');
      var sidebar = document.getElementById('CollectionSidebar');
      if (!btn || !sidebar) return;
      btn.addEventListener('click', function() {
        sidebar.classList.toggle('active');
        document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
      });
    }
  };

  // ============================================================
  // VIEW TOGGLE (grid/list)
  // ============================================================
  var ViewToggle = {
    init: function() {
      var btns = document.querySelectorAll('.view-btn');
      var grid = document.getElementById('CollectionProducts');
      if (!btns.length || !grid) return;
      btns.forEach(function(btn) {
        btn.addEventListener('click', function() {
          btns.forEach(function(b) { b.classList.remove('active'); });
          this.classList.add('active');
          var view = this.dataset.view;
          grid.className = grid.className.replace(/products-grid--\S+/g, '');
          if (view === 'grid3') grid.classList.add('products-grid--3col');
          else if (view === 'list') grid.classList.add('products-grid--list');
          else grid.classList.add('products-grid--4col');
        });
      });
    }
  };

  // ============================================================
  // CART AJAX UPDATES
  // ============================================================
  var Cart = {
    init: function() {
      // Remove items
      document.addEventListener('click', function(e) {
        if (e.target.classList.contains('cart-item__remove')) {
          var key = e.target.dataset.key;
          Cart.updateItem(key, 0);
        }
      });

      // Quantity change
      document.addEventListener('change', function(e) {
        if (e.target.classList.contains('cart-qty-input')) {
          var key = e.target.dataset.key;
          var qty = parseInt(e.target.value);
          Cart.updateItem(key, qty);
        }
      });
    },

    updateItem: function(key, qty) {
      fetch('/cart/change.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: key, quantity: qty })
      })
      .then(function(r) { return r.json(); })
      .then(function(cart) {
        Cart.updateUI(cart);
      })
      .catch(function(err) { console.error('Cart update error:', err); });
    },

    updateUI: function(cart) {
      // Update cart count badge
      var badge = document.querySelector('.cart-count');
      if (badge) badge.textContent = cart.item_count;

      // Reload page to reflect changes
      window.location.reload();
    }
  };

  // ============================================================
  // ADD TO CART
  // ============================================================
  var AddToCart = {
    init: function() {
      var form = document.getElementById('ProductForm');
      if (!form) return;

      form.addEventListener('submit', function(e) {
        e.preventDefault();
        var btn = document.getElementById('AddToCart');
        var originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
        btn.disabled = true;

        var formData = new FormData(form);
        fetch('/cart/add.js', {
          method: 'POST',
          body: formData
        })
        .then(function(r) { return r.json(); })
        .then(function(item) {
          btn.innerHTML = '<i class="fas fa-check"></i> Added!';
          btn.style.background = 'var(--color-success)';
          AddToCart.updateCartCount();
          setTimeout(function() {
            btn.innerHTML = originalText;
            btn.style.background = '';
            btn.disabled = false;
          }, 2000);
        })
        .catch(function() {
          btn.innerHTML = originalText;
          btn.disabled = false;
        });
      });

      // Buy Now
      var buyNow = document.getElementById('BuyNow');
      if (buyNow) {
        buyNow.addEventListener('click', function() {
          var variantId = document.getElementById('ProductVariantId').value;
          var qty = document.getElementById('ProductQty') ? document.getElementById('ProductQty').value : 1;
          fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: variantId, quantity: qty })
          })
          .then(function() { window.location.href = '/checkout'; });
        });
      }
    },

    updateCartCount: function() {
      fetch('/cart.js')
      .then(function(r) { return r.json(); })
      .then(function(cart) {
        var badge = document.querySelector('.cart-count');
        if (badge) badge.textContent = cart.item_count;
      });
    }
  };

  // ============================================================
  // PRODUCT RECOMMENDATIONS (AJAX)
  // ============================================================
  var ProductRecommendations = {
    init: function() {
      var section = document.getElementById('ProductRecommendations');
      if (!section) return;
      var productId = section.dataset.productId;
      var container = document.getElementById('RecommendedProducts');
      if (!productId || !container) return;

      fetch('/recommendations/products.json?product_id=' + productId + '&limit=4&section_id=product-recommendations')
      .then(function(r) { return r.json(); })
      .then(function(data) {
        if (data.products && data.products.length) {
          container.innerHTML = '';
          data.products.forEach(function(product) {
            container.innerHTML += ProductRecommendations.buildCard(product);
          });
        } else {
          section.style.display = 'none';
        }
      })
      .catch(function() { section.style.display = 'none'; });
    },

    buildCard: function(p) {
      var img = p.images[0] ? p.images[0].src : '';
      var price = '₹' + (p.price / 100).toLocaleString('en-IN');
      var comparePrice = p.compare_at_price ? '₹' + (p.compare_at_price / 100).toLocaleString('en-IN') : '';
      return '<div class="product-card">' +
        '<div class="product-card__img-wrap">' +
        '<a href="/products/' + p.handle + '">' +
        (img ? '<img class="product-card__img product-card__img--primary" src="' + img + '" alt="' + p.title + '" loading="lazy">' : '') +
        '</a></div>' +
        '<div class="product-card__info">' +
        '<div class="product-card__brand">' + p.vendor + '</div>' +
        '<h3 class="product-card__title"><a href="/products/' + p.handle + '">' + p.title + '</a></h3>' +
        '<div class="product-card__price">' +
        '<span class="price' + (comparePrice ? ' price--sale' : '') + '">' + price + '</span>' +
        (comparePrice ? '<span class="price price--compare">' + comparePrice + '</span>' : '') +
        '</div></div></div>';
    }
  };

  // ============================================================
  // SEARCH AUTOCOMPLETE
  // ============================================================
  var SearchAutocomplete = {
    timeout: null,
    init: function() {
      var input = document.querySelector('.search-input');
      if (!input) return;
      var resultsBox = document.createElement('div');
      resultsBox.className = 'search-autocomplete';
      input.parentNode.appendChild(resultsBox);

      input.addEventListener('input', function() {
        clearTimeout(SearchAutocomplete.timeout);
        var q = this.value.trim();
        if (q.length < 2) { resultsBox.innerHTML = ''; resultsBox.style.display = 'none'; return; }
        SearchAutocomplete.timeout = setTimeout(function() {
          fetch('/search/suggest.json?q=' + encodeURIComponent(q) + '&resources[type]=product&resources[limit]=5')
          .then(function(r) { return r.json(); })
          .then(function(data) {
            var products = data.resources && data.resources.results && data.resources.results.products;
            if (products && products.length) {
              resultsBox.innerHTML = products.map(function(p) {
                return '<a href="' + p.url + '" class="autocomplete-item">' +
                  (p.image ? '<img src="' + p.image + '" alt="' + p.title + '">' : '') +
                  '<div><strong>' + p.title + '</strong><span>' + (p.price ? '₹' + (parseInt(p.price) / 100).toLocaleString('en-IN') : '') + '</span></div>' +
                  '</a>';
              }).join('');
              resultsBox.style.display = 'block';
            } else {
              resultsBox.innerHTML = '';
              resultsBox.style.display = 'none';
            }
          });
        }, 300);
      });

      document.addEventListener('click', function(e) {
        if (!input.contains(e.target)) {
          resultsBox.innerHTML = '';
          resultsBox.style.display = 'none';
        }
      });
    }
  };

  // ============================================================
  // PINCODE CHECKER
  // ============================================================
  var PincodeChecker = {
    init: function() {
      var btn = document.getElementById('CheckPincode');
      if (!btn) return;
      btn.addEventListener('click', function() {
        var pin = document.getElementById('PincodeInput').value.trim();
        var result = document.getElementById('DeliveryResult');
        if (pin.length !== 6 || isNaN(pin)) {
          result.innerHTML = '<span style="color:red">Please enter a valid 6-digit pincode.</span>';
          result.style.display = 'block';
          return;
        }
        result.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking...';
        result.style.display = 'block';
        setTimeout(function() {
          result.innerHTML = '<span style="color:green"><i class="fas fa-check-circle"></i> Delivery available! Estimated 3-5 business days.</span>';
        }, 800);
      });
    }
  };

  // ============================================================
  // QUICK ADD TO CART (collection page)
  // ============================================================
  var QuickAdd = {
    init: function() {
      document.addEventListener('submit', function(e) {
        if (e.target.classList.contains('quick-add-form')) {
          e.preventDefault();
          var form = e.target;
          var btn = form.querySelector('.quick-add-btn');
          var orig = btn.textContent;
          btn.textContent = '✓ Added';
          btn.style.background = 'var(--color-success)';
          fetch('/cart/add.js', { method: 'POST', body: new FormData(form) })
          .then(function() {
            AddToCart.updateCartCount();
            setTimeout(function() { btn.textContent = orig; btn.style.background = ''; }, 2000);
          });
        }
      });
    }
  };

  // ============================================================
  // WISHLIST (localStorage)
  // ============================================================
  var Wishlist = {
    key: 'af_wishlist',
    init: function() {
      document.addEventListener('click', function(e) {
        var btn = e.target.closest('.wishlist-btn, #WishlistBtn');
        if (!btn) return;
        var id = btn.dataset.productId || document.querySelector('[data-product-id]') && document.querySelector('[data-product-id]').dataset.productId;
        if (!id) return;
        var list = Wishlist.get();
        if (list.includes(id)) {
          list = list.filter(function(i) { return i !== id; });
          btn.querySelector('i') && btn.querySelector('i').className.replace('fas', 'far');
        } else {
          list.push(id);
          btn.querySelector('i') && (btn.querySelector('i').className = btn.querySelector('i').className.replace('far', 'fas'));
        }
        Wishlist.save(list);
      });
    },
    get: function() {
      try { return JSON.parse(localStorage.getItem(this.key)) || []; } catch(e) { return []; }
    },
    save: function(list) {
      try { localStorage.setItem(this.key, JSON.stringify(list)); } catch(e) {}
    }
  };

  // ============================================================
  // ANNOUNCEMENT BAR (auto-rotate if multiple messages)
  // ============================================================
  var AnnouncementBar = {
    init: function() {
      // single bar, no rotation needed for base version
    }
  };

  // ============================================================
  // BACK TO TOP
  // ============================================================
  var BackToTop = {
    init: function() {
      var btn = document.createElement('button');
      btn.id = 'BackToTop';
      btn.innerHTML = '<i class="fas fa-chevron-up"></i>';
      btn.setAttribute('aria-label', 'Back to top');
      btn.style.cssText = 'position:fixed;bottom:24px;right:24px;width:42px;height:42px;border-radius:50%;background:var(--color-primary);color:#fff;border:none;cursor:pointer;z-index:999;font-size:16px;display:none;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(0,0,0,0.2);transition:all 0.3s;';
      document.body.appendChild(btn);

      window.addEventListener('scroll', function() {
        btn.style.display = window.scrollY > 400 ? 'flex' : 'none';
      }, { passive: true });

      btn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
  };

  // ============================================================
  // STICKY ADD TO CART (mobile)
  // ============================================================
  var StickyCart = {
    init: function() {
      var productInfo = document.querySelector('.product-info');
      if (!productInfo) return;
      var stickyBar = document.createElement('div');
      stickyBar.className = 'sticky-add-to-cart';
      stickyBar.innerHTML = '<div class="container"><button class="btn btn--primary btn--full" id="StickyAddToCart"><i class="fas fa-shopping-cart"></i> Add to Cart</button></div>';
      document.body.appendChild(stickyBar);

      var addBtn = document.getElementById('AddToCart');
      window.addEventListener('scroll', function() {
        if (!addBtn) return;
        var rect = addBtn.getBoundingClientRect();
        stickyBar.style.display = rect.bottom < 0 ? 'block' : 'none';
      }, { passive: true });

      document.getElementById('StickyAddToCart') && document.getElementById('StickyAddToCart').addEventListener('click', function() {
        if (addBtn) addBtn.click();
      });
    }
  };

  // ============================================================
  // INIT ALL
  // ============================================================
  document.addEventListener('DOMContentLoaded', function() {
    HeroSlider.init();
    MobileMenu.init();
    StickyHeader.init();
    ProductGallery.init();
    ProductVariants.init();
    QuantitySelector.init();
    ProductTabs.init();
    FilterAccordion.init();
    SortBy.init();
    FilterToggle.init();
    ViewToggle.init();
    Cart.init();
    AddToCart.init();
    ProductRecommendations.init();
    SearchAutocomplete.init();
    PincodeChecker.init();
    QuickAdd.init();
    Wishlist.init();
    AnnouncementBar.init();
    BackToTop.init();
    StickyCart.init();
  });

})();
