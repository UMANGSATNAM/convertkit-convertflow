# Asian Footwears – Custom Shopify Theme

A complete, pixel-perfect Shopify theme replicating the design and functionality of **asianfootwears.com**.

---

## 📦 Theme Structure

```
asian-footwears-theme/
├── assets/
│   ├── theme.css              # Main stylesheet
│   ├── theme-extra.css        # Additional styles (autocomplete, grid variants)
│   ├── theme-blog.css         # Blog & article styles
│   └── theme.js               # All JavaScript functionality
├── config/
│   ├── settings_schema.json   # Theme settings definition
│   └── settings_data.json     # Default settings values
├── layout/
│   ├── theme.liquid           # Main layout (header + footer wrapper)
│   └── password.liquid        # Coming Soon / Password page
├── locales/
│   └── en.default.json        # English translations
├── sections/
│   ├── announcement-bar.liquid
│   ├── header.liquid          # Full header with mega menu
│   ├── footer.liquid          # Full footer with newsletter
│   ├── hero-slider.liquid     # Homepage hero banner slider
│   ├── category-grid.liquid   # Shop by category grid
│   ├── featured-products.liquid
│   ├── promo-banners.liquid   # Double promo banners
│   ├── new-arrivals.liquid
│   ├── brand-strip.liquid
│   ├── testimonials.liquid
│   ├── features-strip.liquid  # Free shipping, returns, etc.
│   ├── product-template.liquid
│   ├── product-recommendations.liquid
│   ├── collection-template.liquid
│   ├── cart-template.liquid
│   └── page-template.liquid
├── snippets/
│   ├── product-card.liquid
│   └── product-card-placeholder.liquid
└── templates/
    ├── index.liquid           # Homepage
    ├── product.liquid
    ├── collection.liquid
    ├── cart.liquid
    ├── blog.liquid
    ├── article.liquid
    ├── search.liquid
    ├── page.liquid
    ├── 404.liquid
    └── customers/
        ├── account.liquid
        ├── login.liquid
        └── register.liquid
```

---

## 🚀 Installation

### Method 1: Upload via Shopify Admin (Recommended)

1. **Zip the theme folder:**
   - Compress the entire `asian-footwears-theme` folder into a `.zip` file

2. **Upload to Shopify:**
   - Go to **Shopify Admin → Online Store → Themes**
   - Click **"Add theme"** → **"Upload zip file"**
   - Select your zipped theme file
   - Click **"Upload"**

3. **Preview and Publish:**
   - Click **"Customize"** to preview the theme
   - Click **"Publish"** to make it live

### Method 2: Shopify CLI

```bash
shopify theme push --path ./asian-footwears-theme
```

---

## ⚙️ Theme Setup

### 1. Header
Go to **Customize → Header section** and:
- Upload your **logo** (recommended: PNG with transparent background, 200px wide)
- Set **phone number** and **email** for the top bar

### 2. Hero Slider
Go to **Customize → Hero Slider** and:
- Add 2–5 slides
- Upload background images (recommended: 1920×600px)
- Set titles, subtitles, descriptions and button links for each slide

### 3. Category Grid
- Add category cards (up to 6)
- Upload category images (square, 400×400px)
- Set correct collection links

### 4. Featured Products & New Arrivals
- Select a **Shopify Collection** to pull products from
- Set number of products to display

### 5. Footer
- Upload **footer logo**
- Fill in **address, phone, email, working hours**
- Add **social media URLs** (Facebook, Instagram, Twitter, YouTube)
- Write a short **about text** for brand description

### 6. Brand Strip
- Add your brand logos (recommend: PNG transparent, max 160×60px)

### 7. Testimonials
- Add customer reviews with name, location, rating and review text

### 8. Features Strip (Trust Badges)
- Pre-configured with: Free Shipping, Easy Returns, 100% Genuine, 24/7 Support
- Edit icon classes (Font Awesome 6) and text as needed

---

## 🎨 Customization

### Brand Colors
Edit in **Customize → Theme Settings → Colors:**
- **Primary Color:** `#d32f2f` (Red – main brand color)
- **Secondary Color:** `#1a1a2e` (Dark Navy – nav, footer)
- **Accent Color:** `#ff6f00` (Orange – highlights)

Or edit directly in `assets/theme.css` under `:root { }` variables.

### Fonts
The theme uses:
- **Rajdhani** (headings) – Bold, uppercase footwear brand feel
- **Nunito Sans** (body) – Clean and readable

Change via **Customize → Theme Settings → Typography**.

---

## 🛍️ Key Features

| Feature | Details |
|---|---|
| **Hero Slider** | Auto-play, dots navigation, prev/next arrows |
| **Mega Menu** | 3-column dropdown for Men's, Women's, Kids |
| **Mobile Menu** | Slide-out with sub-menu accordion |
| **Search Autocomplete** | Live product suggestions as you type |
| **Product Gallery** | Thumbnail + main image with hover swap |
| **Size Selector** | Visual size buttons with unavailable states |
| **Color Swatches** | Color circle swatches |
| **Add to Cart (AJAX)** | No page reload, updates cart count |
| **Buy Now** | Direct checkout button |
| **Pincode Checker** | Delivery availability by pincode |
| **Product Tabs** | Description, Specs, Reviews, Size Guide |
| **Product Recommendations** | Shopify AI-powered recommendations |
| **Collection Filters** | Category, Size, Color, Price, Brand, Discount |
| **Sort & View Toggle** | Grid 4/3/list view + sort by options |
| **Cart Page** | AJAX quantity update & remove |
| **Free Shipping Progress** | Progress bar toward free shipping threshold |
| **Wishlist** | localStorage-based wishlist |
| **Testimonials** | Dark background review cards grid |
| **Newsletter** | Integrated with Shopify customer email |
| **Blog** | Grid layout with tags and excerpts |
| **Back to Top Button** | Auto-shows on scroll |
| **Sticky Mobile Cart** | Fixed add-to-cart on mobile product page |
| **Trust Badges** | Genuine, Returns, Fast Delivery, Secure Payment |

---

## 📱 Responsive Breakpoints

| Breakpoint | Layout |
|---|---|
| `< 480px` | Single column, simplified header |
| `480px – 768px` | 2-column product grid |
| `768px – 1024px` | 3-column product grid, tablet layout |
| `> 1024px` | Full desktop layout, mega menu visible |

---

## 🔧 Customizing Navigation

The mega menu links are hardcoded in `sections/header.liquid`. To add/remove links:
1. Open `sections/header.liquid`
2. Edit the `<ul class="main-nav__list">` section
3. Update collection handles to match your Shopify store's collections

---

## 💳 Payment Icons in Footer

The theme references payment SVG assets in the footer. Add these to your `assets/` folder:
- `payment-visa.svg`
- `payment-mastercard.svg`
- `payment-upi.svg`
- `payment-paytm.svg`
- `payment-rupay.svg`

Or replace the `<img>` tags in `sections/footer.liquid` with Font Awesome payment icons.

---

## 📧 Support

Built to replicate asianfootwears.com for Shopify.

For Shopify Liquid documentation: https://shopify.dev/docs/api/liquid
